<?php

namespace App\Http\Controllers;

use App\Helpers\Decode;
use App\Helpers\Encode;
use App\Helpers\Mssql;
use App\Http\Requests\LoginRequest;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;

class ApiController extends Controller
{
    public function login(LoginRequest $request)
    {
        $response = procedure("Get_UserLogin", [
            'Useremail' => $request->Useremail,
            'Password' => $request->Password
        ], true);
        if (isFailed($response)) {
            return response()->json([
                'code' => 401,
                'status' => 'error',
                'message' => 'Failed login'
            ], 401);
        }

        $token = Encode::jwt(['response' => $response]);
        mssql()->generateVerifyCode($response->UserID);

        return response()->json([
            'code' => 200,
            'status' => 'success',
            'message' => 'verify otp',
            'verify' => 1,
            'token' => $token
        ]);
    }

    public function verify()
    {
        dd(
            request()->decoded,
          Decode::jwt('1')
        );
    }

    public function resendVerify(Request $request)
    {
        // user_id and otp code
        // kod oluştur dbye yaz (prosedür) sonra mail gödmner
        // doğrulama adımı
        $data = array('name'=>"Virat Gandhi");

        Mail::send(['text'=>'mail'], $data, function($message) {
            $message->to('mchtylmz149@gmail.com', 'mcht')->subject
            ('Laravel Basic Mail');
            $message->from('ismail@adlookups.com', 'Ismail');
        });
    }

    // login
    // verify -> resend
    // verify token change

    public function get(string $name)
    {
        $params = json_decode(request()->getContent(), true) ?? [];
        $results = procedure($name, $params);

        return response()->json([
            'total' => count($results),
            'results' => $results,
            'params' => $params
        ]);
    }
}
