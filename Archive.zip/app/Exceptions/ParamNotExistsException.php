<?php

namespace App\Exceptions;
use Exception;

class ParamNotExistsException extends Exception
{

}
